
class Player {
  String name;
  int position;
  int number;
 

  Player({
    required this.name,
    required this.position,
    required this.number,

  });
}
