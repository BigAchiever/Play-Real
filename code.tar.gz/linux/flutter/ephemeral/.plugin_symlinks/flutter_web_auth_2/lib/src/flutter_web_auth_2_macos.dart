// MacOS just needs the MethodChannel implementation
