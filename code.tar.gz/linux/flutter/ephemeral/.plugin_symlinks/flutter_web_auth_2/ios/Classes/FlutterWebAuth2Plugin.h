#import <Flutter/Flutter.h>

@interface FlutterWebAuth2Plugin : NSObject<FlutterPlugin>
@end
