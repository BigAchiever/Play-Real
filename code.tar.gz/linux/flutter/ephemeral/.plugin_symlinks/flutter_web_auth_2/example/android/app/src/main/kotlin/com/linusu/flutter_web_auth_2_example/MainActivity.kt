package com.linusu.flutter_web_auth_2_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
