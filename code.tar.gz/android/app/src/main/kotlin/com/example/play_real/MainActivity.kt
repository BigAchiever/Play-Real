package com.example.play_real

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
